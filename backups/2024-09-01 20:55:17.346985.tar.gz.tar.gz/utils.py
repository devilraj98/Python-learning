import os 
print(os.system('df -h')) #Linux or Mac
print(os.system('uptime')) #Uptime and load average
print(os.system('free -h')) # Ram for linux
