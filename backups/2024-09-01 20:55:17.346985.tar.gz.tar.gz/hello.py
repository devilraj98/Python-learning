name = input("Enter your username:")
print("Your usernames are",name)