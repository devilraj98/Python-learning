#Data structure - list

list_of_clouds = ["cloud1", "cloud2", "cloud3", "cloud4", "cloud5", "cloud6"]
print(list_of_clouds)

list_of_clouds.append("salesforce")

print(list_of_clouds)

list_of_clouds.remove("cloud6")

print(list_of_clouds)

print(len(list_of_clouds))

list_of_clouds.insert(2,"AWS")

print(list_of_clouds)

################################################################
#for loop

for a in list_of_clouds:
    print(a)

for i in range(1,10):
        print(i)