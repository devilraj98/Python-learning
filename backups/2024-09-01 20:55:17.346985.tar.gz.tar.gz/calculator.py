num1 = int(input("please enter your first number"))
num2 = int(input("please enter your second number"))

sum = num1 + num2
diff = num1 - num2
product =  num1 * num2
div = num1 / num2

print("The sum of", num1, "and", num2, "is", sum)
print("The difference of", num1, "and", num2, "is", diff)
print("The product of", num1, "and", num2, "is", product)
print("The division of", num1, "and", num2, "is", div)



